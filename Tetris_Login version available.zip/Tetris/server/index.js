const express = require('express');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const path = require('path');
const dotenv = require('dotenv');
const mysql = require('mysql2/promise');

dotenv.config();

const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'dev_secret';
const DB_HOST = process.env.DB_HOST || 'localhost';
const DB_USER = process.env.DB_USER || 'root';
const DB_PASSWORD = process.env.DB_PASSWORD || '';
const DB_NAME = process.env.DB_NAME || 'tetris_db';

let pool; // MySQL pool connected to DB

async function initDb() {
  const serverConn = await mysql.createConnection({ host: DB_HOST, user: DB_USER, password: DB_PASSWORD });
  await serverConn.query(`CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`);
  await serverConn.end();

  pool = mysql.createPool({
    host: DB_HOST,
    user: DB_USER,
    password: DB_PASSWORD,
    database: DB_NAME,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
  });

  // 初始化数据库中的表结构
  // users 增加 email、is_active、last_login_at、updated_at
  // scores 增加 lines、level、duration_sec，并添加索引
  await pool.query(`CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(64) UNIQUE NOT NULL,
    email VARCHAR(120) DEFAULT NULL,
    password_hash VARCHAR(255) NOT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    last_login_at DATETIME DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
  
  await pool.query(`CREATE TABLE IF NOT EXISTS scores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    score INT NOT NULL,
    lines_cleared INT NOT NULL DEFAULT 0,
    level INT NOT NULL DEFAULT 1,
    duration_sec INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_score (user_id, score)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

  console.log(`MySQL connected and ensured DB/tables at ${DB_NAME}`);
}

function createAuthMiddleware() {
  return async function (req, res, next) {
    const auth = req.headers.authorization || '';
    const token = auth.startsWith('Bearer ') ? auth.slice(7) : null;
    if (!token) return res.status(401).json({ error: '未登录' });
    try {
      const payload = jwt.verify(token, JWT_SECRET);
      req.user = payload; // { userId, username }
      next();
    } catch (e) {
      return res.status(401).json({ error: '令牌无效或过期' });
    }
  };
}

const app = express();
app.use(cors());
app.use(express.json());

// Static frontend
app.use(express.static(path.join(__dirname, '..', 'public')));

// API: Register
app.post('/api/register', async (req, res) => {
  try {
    if (!pool) return res.status(500).json({ error: '数据库未连接' });
    const { username, password, email } = req.body;
    if (!username || !password) return res.status(400).json({ error: '用户名和密码不能为空' });
    const [rows] = await pool.query('SELECT id FROM users WHERE username = ?', [username]);
    if (rows.length > 0) return res.status(409).json({ error: '用户名已存在' });
    const hash = await bcrypt.hash(password, 10);
    await pool.query('INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)', [username, email || null, hash]);
    return res.json({ message: '注册成功' });
  } catch (e) {
    console.error('Register error:', e);
    return res.status(500).json({ error: '服务器错误' });
  }
});

// API: Login
app.post('/api/login', async (req, res) => {
  try {
    if (!pool) return res.status(500).json({ error: '数据库未连接' });
    const { username, password } = req.body;
    if (!username || !password) return res.status(400).json({ error: '用户名和密码不能为空' });
    const [rows] = await pool.query('SELECT id, password_hash FROM users WHERE username = ?', [username]);
    if (rows.length === 0) return res.status(401).json({ error: '用户名或密码错误' });
    const user = rows[0];
    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) return res.status(401).json({ error: '用户名或密码错误' });
    await pool.query('UPDATE users SET last_login_at = NOW() WHERE id = ?', [user.id]);
    const token = jwt.sign({ userId: user.id, username }, JWT_SECRET, { expiresIn: '7d' });
    return res.json({ token });
  } catch (e) {
    console.error('Login error:', e);
    return res.status(500).json({ error: '服务器错误' });
  }
});

// 重排：存分接口见后文统一定义

const auth = createAuthMiddleware();

// API: Me
app.get('/api/me', auth, async (req, res) => {
  res.json({ username: req.user.username });
});

// API: Save score（接受更多可选统计字段）
app.post('/api/score', auth, async (req, res) => {
  try {
    if (!pool) return res.status(500).json({ error: '数据库未连接' });
    const { score, lines = 0, level = 1, duration_sec = 0 } = req.body;
    const s = Number(score);
    if (!Number.isFinite(s) || s < 0) return res.status(400).json({ error: '成绩无效' });
    await pool.query('INSERT INTO scores (user_id, score, lines_cleared, level, duration_sec) VALUES (?, ?, ?, ?, ?)', [req.user.userId, s, Number(lines)||0, Number(level)||1, Number(duration_sec)||0]);
    res.json({ message: '成绩已保存' });
  } catch (e) {
    console.error('Score error:', e);
    res.status(500).json({ error: '服务器错误' });
  }
});

// API: Top scores for current user
app.get('/api/scores', auth, async (req, res) => {
  try {
    if (!pool) return res.status(500).json({ error: '数据库未连接' });
    const [rows] = await pool.query('SELECT score, created_at FROM scores WHERE user_id = ? ORDER BY score DESC, created_at DESC LIMIT 10', [req.user.userId]);
    res.json({ scores: rows });
  } catch (e) {
    console.error('Scores list error:', e);
    res.status(500).json({ error: '服务器错误' });
  }
});

// 排行榜：按每个用户的最高分降序排名，返回 Top 10 以及当前用户的排名与最高分
app.get('/api/leaderboard', auth, async (req, res) => {
  try {
    if (!pool) return res.status(500).json({ error: '数据库未连接' });
    const [topRows] = await pool.query(`
      SELECT u.username, COALESCE(MAX(s.score), 0) AS best_score
      FROM users u
      LEFT JOIN scores s ON s.user_id = u.id
      GROUP BY u.id, u.username
      ORDER BY best_score DESC, u.id ASC
      LIMIT 10
    `);

    const [[meBestRow]] = await pool.query(`SELECT MAX(score) AS best_score FROM scores WHERE user_id = ?`, [req.user.userId]);
    const meBest = meBestRow && meBestRow.best_score != null ? Number(meBestRow.best_score) : null;

    let meRank = null;
    if (meBest != null) {
      const [[rankRow]] = await pool.query(`
        SELECT 1 + COUNT(*) AS my_rank
        FROM (
          SELECT user_id, MAX(score) AS best FROM scores GROUP BY user_id
        ) t
        WHERE t.best > ?
      `, [meBest]);
      meRank = rankRow && rankRow.my_rank != null ? Number(rankRow.my_rank) : null;
    }

    res.json({ top: topRows, me: { username: req.user.username, best_score: meBest || 0, rank: meRank } });
  } catch (e) {
    console.error('Leaderboard error:', e);
    res.status(500).json({ error: '服务器错误' });
  }
});

// Fallback to index.html
// app.get('*', (req, res) => {
//   res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
// });
app.use((req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

(async () => {
  try {
    await initDb();
    app.listen(PORT, () => {
      console.log(`Server running at http://localhost:${PORT}`);
    });
  } catch (e) {
    console.error('Failed to init DB, server will still start for UI preview:', e);
    pool = null;
    app.listen(PORT, () => {
      console.log(`Server running (no DB) at http://localhost:${PORT}`);
    });
  }
})();