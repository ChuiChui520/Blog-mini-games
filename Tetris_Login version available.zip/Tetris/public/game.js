// 简易俄罗斯方块实现：10x20 网格 + 下一个预览 + 计分
const canvas = document.getElementById('gameCanvas');
const nextCanvas = document.getElementById('nextCanvas');
const ctx = canvas.getContext('2d');
const nctx = nextCanvas.getContext('2d');
const scoreEl = document.getElementById('score');
const btnStart = document.getElementById('btnStart');
const btnLeft = document.getElementById('btnLeft');
const btnRight = document.getElementById('btnRight');
const btnRotate = document.getElementById('btnRotate');
const btnDown = document.getElementById('btnDown');
const overlay = document.getElementById('overlay');
const finalScoreEl = document.getElementById('finalScore');
const btnRestart = document.getElementById('btnRestart');

const COLS = 10, ROWS = 20, SIZE = 30; // canvas 300x600
const COLORS = {
  I: '#2ed573', O: '#ffa502', T: '#3742fa', S: '#ff4757', Z: '#70a1ff', J: '#1e90ff', L: '#eccc68', X: '#57606f'
};

const PIECES = {
  I: [[1,1,1,1]],
  O: [[1,1],[1,1]],
  T: [[1,1,1],[0,1,0]],
  S: [[0,1,1],[1,1,0]],
  Z: [[1,1,0],[0,1,1]],
  J: [[1,0,0],[1,1,1]],
  L: [[0,0,1],[1,1,1]]
};

let board, cur, next, x, y, dropTimer, dropInterval = 700, score = 0, running = false;

function emptyBoard() { return Array.from({ length: ROWS }, () => Array(COLS).fill(0)); }
function randomPiece() { const keys = Object.keys(PIECES); const k = keys[Math.floor(Math.random()*keys.length)]; return { k, m: PIECES[k].map(r=>r.slice()) }; }
function rotate(m) { const h=m.length,w=m[0].length; const res=Array.from({length:w},()=>Array(h).fill(0)); for(let i=0;i<h;i++)for(let j=0;j<w;j++)res[j][h-1-i]=m[i][j]; return res; }
function collide(nx=x, ny=y, nm=cur.m) {
  for(let i=0;i<nm.length;i++) for(let j=0;j<nm[0].length;j++) {
    if(!nm[i][j]) continue; const yy = ny + i, xx = nx + j;
    if(xx<0||xx>=COLS||yy>=ROWS) return true; if(yy>=0 && board[yy][xx]) return true;
  }
  return false;
}
function merge() { for(let i=0;i<cur.m.length;i++) for(let j=0;j<cur.m[0].length;j++) if(cur.m[i][j] && y+i>=0) board[y+i][x+j]=cur.k; }
function clearLines() {
  let cleared = 0; for(let r=ROWS-1;r>=0;r--) {
    if(board[r].every(v=>v)) { board.splice(r,1); board.unshift(Array(COLS).fill(0)); cleared++; r++; }
  }
  if(cleared>0) { const pts=[0,100,300,500,800]; score += pts[cleared]; scoreEl.textContent = score; }
}
function spawn() {
  cur = next || randomPiece(); next = randomPiece(); x = Math.floor((COLS - cur.m[0].length)/2); y = -1;
  drawNext();
  if(collide(x, y+1, cur.m)) { gameOver(); return; }
}
function drawCell(cx, cy, color) { ctx.fillStyle=color; ctx.fillRect(cx*SIZE+1, cy*SIZE+1, SIZE-2, SIZE-2); }
function drawBoard() {
  ctx.clearRect(0,0,canvas.width,canvas.height);
  for(let r=0;r<ROWS;r++) for(let c=0;c<COLS;c++) if(board[r][c]) drawCell(c,r,COLORS[board[r][c]]||COLORS.X);
  if(cur) for(let i=0;i<cur.m.length;i++) for(let j=0;j<cur.m[0].length;j++) if(cur.m[i][j]) { const yy=y+i, xx=x+j; if(yy>=0) drawCell(xx,yy,COLORS[cur.k]); }
}
function drawNext() {
  nctx.clearRect(0,0,nextCanvas.width,nextCanvas.height);
  const m = next.m; const cell = 24; const offX = Math.floor((nextCanvas.width - m[0].length*cell)/2); const offY = Math.floor((nextCanvas.height - m.length*cell)/2);
  for(let i=0;i<m.length;i++) for(let j=0;j<m[0].length;j++) if(m[i][j]) { nctx.fillStyle = COLORS[next.k]; nctx.fillRect(offX + j*cell + 1, offY + i*cell + 1, cell-2, cell-2); }
}
function stepDown() {
  if (!running) return;
  if (!collide(x, y+1)) { y++; }
  else {
    // 如果刚生成位置就无法下落，说明堆顶已触顶，触发游戏结束
    if (y < 0) { gameOver(); return; }
    merge(); clearLines(); spawn();
  }
  drawBoard();
}
async function startGame() {
  // 只有已登录玩家才能开始
  if (window.AuthAPI) {
    const me = await window.AuthAPI.me();
    if (!me || !me.username) {
      alert('请先登录后再开始游戏');
      return;
    }
  }
  board = emptyBoard(); score = 0; scoreEl.textContent = '0'; running = true; overlay.classList.add('hidden');
  cur = null; next = randomPiece(); spawn(); drawBoard();
  if(dropTimer) clearInterval(dropTimer); dropTimer = setInterval(stepDown, dropInterval);
}
function gameOver() {
  running = false;
  clearInterval(dropTimer);
  dropTimer = null;
  // 停止背景音乐
  try { if (Music && Music.isPlaying()) { Music.stop(); } } catch {}
  finalScoreEl.textContent = score;
  // 显示游戏结束弹层，短暂提示后自动返回主界面
  overlay.classList.remove('hidden');
  setTimeout(() => { overlay.classList.add('hidden'); }, 1200);
  // 保存成绩后刷新排行榜（若已登录）
  if (window.AuthAPI) {
    window.AuthAPI.saveScore(score)
      .then(() => { try { loadLeaderboard(); } catch (e) {} })
      .catch(() => {});
  }
}

function tryRotate() { const m2 = rotate(cur.m); if(!collide(x,y,m2)) { cur.m = m2; drawBoard(); } }
function tryMove(dx) { if(!collide(x+dx,y)) { x+=dx; drawBoard(); } }
function softDrop() {
  if(!collide(x,y+1)) { y++; drawBoard(); }
  else {
    // 刚生成即无法下落，视为游戏结束
    if (y < 0) { gameOver(); return; }
    merge(); clearLines(); spawn(); drawBoard();
  }
}
async function startGame() {
  // 只有已登录玩家才能开始
  if (window.AuthAPI) {
    const me = await window.AuthAPI.me();
    if (!me || !me.username) {
      alert('请先登录后再开始游戏');
      return;
    }
  }
  // 启动音乐（如未播放）
  try { if (!Music.isPlaying()) { Music.start(); } } catch {}
  board = emptyBoard(); score = 0; scoreEl.textContent = '0'; running = true; overlay.classList.add('hidden');
  cur = null; next = randomPiece(); spawn(); drawBoard();
  if(dropTimer) clearInterval(dropTimer); dropTimer = setInterval(stepDown, dropInterval);
}
function gameOver() {
  running = false;
  clearInterval(dropTimer);
  dropTimer = null;
  finalScoreEl.textContent = score;
  // 显示游戏结束弹层，短暂提示后自动返回主界面
  overlay.classList.remove('hidden');
  setTimeout(() => { overlay.classList.add('hidden'); }, 1200);
  // 保存成绩后刷新排行榜（若已登录）
  if (window.AuthAPI) {
    window.AuthAPI.saveScore(score)
      .then(() => { try { loadLeaderboard(); } catch (e) {} })
      .catch(() => {});
  }
}

function tryRotate() { const m2 = rotate(cur.m); if(!collide(x,y,m2)) { cur.m = m2; drawBoard(); } }
function tryMove(dx) { if(!collide(x+dx,y)) { x+=dx; drawBoard(); } }
// 移除重复的 softDrop 定义，统一使用上方带顶部判定的版本

btnStart.addEventListener('click', () => startGame());
btnRestart && btnRestart.addEventListener('click', () => startGame());
btnRestart && btnRestart.addEventListener('click', () => startGame());

// 重复的 gameOver 与绑定已移除
btnLeft.addEventListener('click', () => tryMove(-1));
btnRight.addEventListener('click', () => tryMove(1));
btnRotate.addEventListener('click', () => tryRotate());
btnDown.addEventListener('mousedown', () => { if (running) { if (dropTimer) clearInterval(dropTimer); dropTimer = setInterval(stepDown, 60); }});
btnDown.addEventListener('mouseup', () => { if (running) { if (dropTimer) clearInterval(dropTimer); dropTimer = setInterval(stepDown, dropInterval); }});

window.addEventListener('keydown', (e) => {
  if(!running) return;
  if(e.key==='ArrowLeft') tryMove(-1);
  else if(e.key==='ArrowRight') tryMove(1);
  else if(e.key==='ArrowUp') tryRotate();
  else if(e.key==='ArrowDown') softDrop();
});

// 初始绘制背景格线（可选）
(function drawGrid(){
  ctx.strokeStyle = '#1e2430'; ctx.lineWidth = 1;
  for(let r=0;r<=ROWS;r++){ ctx.beginPath(); ctx.moveTo(0,r*SIZE); ctx.lineTo(COLS*SIZE,r*SIZE); ctx.stroke(); }
  for(let c=0;c<=COLS;c++){ ctx.beginPath(); ctx.moveTo(c*SIZE,0); ctx.lineTo(c*SIZE,ROWS*SIZE); ctx.stroke(); }
})();

// 绑定排行榜
const leaderboardList = document.getElementById('leaderboardList');
const myRank = document.getElementById('myRank');
const btnRefreshLb = document.getElementById('btnRefreshLb');

async function loadLeaderboard() {
  try {
    const token = localStorage.getItem('token');
    const meInfo = window.AuthAPI ? await window.AuthAPI.me() : null;
    if (!token || !meInfo) {
      leaderboardList.innerHTML = '';
      myRank.textContent = '请登录以查看个人排名';
      return;
    }
    const res = await fetch('/api/leaderboard', { headers: { Authorization: 'Bearer ' + token } });
    if (!res.ok) { myRank.textContent = '排行榜获取失败'; return; }
    const ct = res.headers.get('content-type') || '';
    if (!ct.includes('application/json')) { myRank.textContent = '请登录以查看个人排名'; return; }
    const data = await res.json();
    const { top = [], me = null } = data;

    leaderboardList.innerHTML = '';
    top.forEach((row, idx) => {
      const li = document.createElement('li');
      li.textContent = `${idx + 1}. ${row.username} — ${row.best_score}`;
      leaderboardList.appendChild(li);
    });

    if (me && me.rank) {
      myRank.textContent = `我的排名：第 ${me.rank} 名，最高分 ${me.best_score}`;
    } else {
      myRank.textContent = '请登录以查看个人排名';
    }
  } catch (err) {
    myRank.textContent = '排行榜获取失败';
    console.error(err);
  }
}

btnRefreshLb?.addEventListener('click', loadLeaderboard);

// 在登录后或页面载入时尝试加载
window.addEventListener('load', loadLeaderboard);
// 音乐控制
const btnMusicToggle = document.getElementById('btnMusicToggle');
const musicVolume = document.getElementById('musicVolume');

const Music = (() => {
  let ctx, master, melodyOsc, bassOsc, intervalId = null;
  let playing = false;
  let vol = 0.4;
  function ensureCtx() {
    if (!ctx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      ctx = new AC();
      master = ctx.createGain();
      master.gain.value = vol;
      master.connect(ctx.destination);
    }
    if (ctx && ctx.state === 'suspended') ctx.resume();
  }
  function start() {
    ensureCtx();
    if (!ctx || playing) return;
    playing = true;
    const tempo = 110; // BPM
    const beatMs = (60 / tempo) * 1000;
    melodyOsc = ctx.createOscillator(); melodyOsc.type = 'square';
    const melodyGain = ctx.createGain(); melodyGain.gain.value = 0.06;
    melodyOsc.connect(melodyGain); melodyGain.connect(master); melodyOsc.start();
    bassOsc = ctx.createOscillator(); bassOsc.type = 'triangle';
    const bassGain = ctx.createGain(); bassGain.gain.value = 0.08;
    bassOsc.connect(bassGain); bassGain.connect(master); bassOsc.start();
    const scale = [261.63,293.66,329.63,349.23,392.00,440.00,493.88]; // C大调
    const pattern = [0,2,4,5,4,2,0,6,5,4,2,0];
    const bassPattern = [0,-12,0,-7]; // 根音律动
    let step = 0;
    intervalId = setInterval(() => {
      const p = pattern[step % pattern.length];
      const freq = scale[p % scale.length];
      melodyOsc.frequency.setValueAtTime(freq, ctx.currentTime);
      const bp = bassPattern[step % bassPattern.length];
      const base = 130.81; // C3
      bassOsc.frequency.setValueAtTime(base*Math.pow(2, bp/12), ctx.currentTime);
      step++;
    }, beatMs);
    refreshUi();
  }
  function stop() {
    if (!playing) return;
    playing = false;
    if (intervalId) { clearInterval(intervalId); intervalId = null; }
    try { melodyOsc.stop(); } catch {}
    try { bassOsc.stop(); } catch {}
    melodyOsc = null; bassOsc = null;
    refreshUi();
  }
  function setVolume(v) { vol = Math.max(0, Math.min(1, v)); ensureCtx(); if (master) master.gain.value = vol; }
  function toggle() { playing ? stop() : start(); }
  function isPlaying() { return playing; }
  function refreshUi() { if (btnMusicToggle) btnMusicToggle.textContent = isPlaying() ? '音乐：关闭' : '音乐：开启'; }
  return { start, stop, toggle, setVolume, isPlaying, ensureCtx };
})();

btnMusicToggle?.addEventListener('click', () => { Music.toggle(); });
musicVolume?.addEventListener('input', (e) => Music.setVolume(Number(e.target.value)));

// 在开始游戏时自动启用音乐（一次用户交互即可满足浏览器策略）
// ... existing code ...