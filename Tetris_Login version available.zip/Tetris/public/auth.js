const API = {
  async register(username, password) {
    const res = await fetch('/api/register', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });
    return res.json();
  },
  async login(username, password) {
    const res = await fetch('/api/login', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });
    return res.json();
  },
  async me() {
    const token = localStorage.getItem('token');
    if (!token) return null;
    const res = await fetch('/api/me', { headers: { Authorization: 'Bearer ' + token } });
    if (!res.ok) return null; return res.json();
  },
  async saveScore(score) {
    const token = localStorage.getItem('token');
    if (!token) return;
    await fetch('/api/score', {
      method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token },
      body: JSON.stringify({ score })
    });
  }
};

const userBox = document.getElementById('userBox');
const authSection = document.getElementById('authSection');
const gameSection = document.getElementById('gameSection');
const tabLogin = document.getElementById('tabLogin');
const tabRegister = document.getElementById('tabRegister');
const loginForm = document.getElementById('loginForm');
const registerForm = document.getElementById('registerForm');
const loginMsg = document.getElementById('loginMsg');
const registerMsg = document.getElementById('registerMsg');
const btnLogout = document.getElementById('btnLogout');

function setTab(which) {
  if (which === 'login') {
    tabLogin.classList.add('active'); tabRegister.classList.remove('active');
    loginForm.classList.remove('hidden'); registerForm.classList.add('hidden');
  } else {
    tabRegister.classList.add('active'); tabLogin.classList.remove('active');
    registerForm.classList.remove('hidden'); loginForm.classList.add('hidden');
  }
}

async function refreshUser() {
  const me = await API.me();
  if (me && me.username) {
    userBox.textContent = `已登录：${me.username}`;
    authSection.classList.add('hidden');
    gameSection.classList.remove('hidden');
    if (btnLogout) btnLogout.style.display = 'inline-block';
  } else {
    userBox.textContent = '未登录';
    authSection.classList.remove('hidden');
    gameSection.classList.add('hidden');
    if (btnLogout) btnLogout.style.display = 'none';
  }
}

btnLogout?.addEventListener('click', async () => {
  localStorage.removeItem('token');
  await refreshUser();
});
tabLogin.addEventListener('click', () => setTab('login'));
tabRegister.addEventListener('click', () => setTab('register'));

loginForm.addEventListener('submit', async (e) => {
  e.preventDefault(); loginMsg.textContent = '';
  const fd = new FormData(loginForm);
  const { username, password } = Object.fromEntries(fd.entries());
  const data = await API.login(username, password);
  if (data.token) { localStorage.setItem('token', data.token); await refreshUser(); }
  else { loginMsg.textContent = data.error || '登录失败'; }
});

registerForm.addEventListener('submit', async (e) => {
  e.preventDefault(); registerMsg.textContent = '';
  const fd = new FormData(registerForm);
  const { username, password } = Object.fromEntries(fd.entries());
  const data = await API.register(username, password);
  if (data.message) { registerMsg.textContent = '注册成功，请登录'; setTab('login'); }
  else { registerMsg.textContent = data.error || '注册失败'; }
});

refreshUser();

// expose API to game
window.AuthAPI = API;